CREATE SCHEMA `autok_adatbazis` DEFAULT CHARACTER SET utf8 COLLATE utf8_hungarian_ci;
USE autok_adatbazis;

CREATE TABLE autok (
  `id` INT NOT NULL AUTO_INCREMENT,
  `rendszam` VARCHAR(20) NOT NULL,
  `netto_ar` DECIMAL(10,2) NOT NULL,
  `gyarto` VARCHAR(100) NOT NULL,
  `modell` VARCHAR(100),
  `futott_km` INT,
  `allapot` BOOLEAN DEFAULT TRUE,
  `kategoria_id` INT,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`kategoria_id`) REFERENCES kategoria(`id`)
);

CREATE TABLE kategoria (
  `id` INT NOT NULL AUTO_INCREMENT,
  `megnevezes` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`id`)
);

INSERT INTO kategoria (`megnevezes`) VALUES ('személyautó');
INSERT INTO kategoria (`megnevezes`) VALUES ('teherautó');
INSERT INTO kategoria (`megnevezes`) VALUES ('egyéb');


INSERT INTO autok (`rendszam`, `netto_ar`, `gyarto`, `modell`, `futott_km`, `allapot`, `kategoria_id`) 
VALUES 
('ABC123', 1500000.00, 'Toyota', 'Corolla', 110000, TRUE, 1),
('XYZ789', 2000000.00, 'Volkswagen', 'Golf', 70000, TRUE, 2),
('DEF456', 1800000.00, 'Ford', 'Focus', 90000, TRUE, 3);
