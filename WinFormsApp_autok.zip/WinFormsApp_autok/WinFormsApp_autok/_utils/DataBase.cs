﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp_autok._utils
{
    public class Database
    {
        public static string connectionString = "server=localhost;database=WinFormsApp_autok;port=3306;user=root;password=''";
        static MySqlConnection mysqlConnection = new MySqlConnection();
        public static MySqlCommand mysqlCommand = new MySqlCommand();

        #region CONNECT
        public void Connect()
        {
            try
            {
                mysqlConnection.ConnectionString = connectionString;
                mysqlConnection.Open();
                mysqlCommand.Connection = mysqlConnection;
            }
            catch (Exception ex)
            {
                throw new Exception("Hiba a kapcsolódáskor:" + ex.Message);
            }
        }
        #endregion

        #region CONNECT
        public void CloseConnection()
        {
            try
            {
                mysqlConnection.Close();
                mysqlCommand.Dispose();
            }
            catch (Exception ex)
            {
                throw new Exception("Hiba a kapcsolódás bontásánál:" + ex.Message);
            }
        }
        #endregion
    }
}