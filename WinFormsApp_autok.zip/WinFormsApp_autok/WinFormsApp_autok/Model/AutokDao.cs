﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using WinFormsApp_autok.Model;
using WinFormsApp_autok._utils;
using System.Data;

namespace WinFormsApp_autok.Model
{
    public class AutokDao
    {
        public List<Autok> GetAllAuto()
        {
            List<Autok> autok = new List<Autok>();

            try
            {
                using (MySqlConnection connection = new MySqlConnection(Database.connectionString))
                {
                    connection.Open();

                    string query = "SELECT autok.id, autok.rendszam, autok.gyarto, autok.modell, kategoria.megnevezes AS kategoria, autok.netto_ar, autok.allapot FROM autok INNER JOIN kategoria ON autok.kategoria_id = kategoria.id";

                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                int id = reader.GetInt32("id");
                                string rendszam = reader.GetString("rendszam");
                                string gyarto = reader.IsDBNull("gyarto") ? null : reader.GetString("gyarto");
                                string modell = reader.GetString("modell");
                                string kategoria = reader.GetString("kategoria");
                                decimal nettoAr = reader.GetDecimal("netto_ar");
                                bool allapot = reader.GetBoolean("allapot");

                                autok.Add(new Autok(id, rendszam, gyarto, modell, kategoria, (int)nettoAr, Convert.ToInt32(allapot)));
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Hiba történt: " + ex.Message);
            }

            return autok;
        }

        private string connectionString = "server=localhost;database=WinFormsApp_autok;port=3306;user=root;password=''";

        public decimal GetAveragePrice()
        {
            decimal sum = 0;
            int count = 0;

            try
            {
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "SELECT ar FROM autok";

                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                decimal price = reader.GetDecimal("ar");
                                sum += price;
                                count++;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Hiba történt az átlagár lekérdezésekor: " + ex.Message);
            }

            if (count == 0)
            {
                return 0;
            }

            decimal averagePrice = sum / count;
            return averagePrice;
        }

        public void AddAuto(string rendszam, string gyarto, string modell, string kategoria, decimal nettoAr, bool allapot)
        {
            try
            {
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "INSERT INTO autok (rendszam, gyarto, modell, kategoria, netto_ar, allapot) VALUES (@rendszam, @gyarto, @modell, @kategoria, @nettoAr, @allapot)";

                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@rendszam", rendszam);
                        command.Parameters.AddWithValue("@gyarto", gyarto);
                        command.Parameters.AddWithValue("@modell", modell);
                        command.Parameters.AddWithValue("@kategoria", kategoria);
                        command.Parameters.AddWithValue("@nettoAr", nettoAr);
                        command.Parameters.AddWithValue("@allapot", allapot);

                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Hiba történt az autó hozzáadásakor az adatbázishoz: " + ex.Message);
            }
        }

        public Autok GetMostExpensiveCar()
        {
            Autok mostExpensiveCar = null;
            decimal maxPrice = decimal.MinValue;

            try
            {
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "SELECT * FROM autok WHERE ar = (SELECT MAX(ar) FROM autok)";

                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                int id = reader.GetInt32("id");
                                string rendszam = reader.GetString("rendszam");
                                string gyarto = reader.GetString("gyarto");
                                string modell = reader.GetString("modell");
                                string kategoria = reader.GetString("kategoria");
                                decimal ar = reader.GetDecimal("ar");
                                int allapot = reader.GetInt32("allapot");

                                mostExpensiveCar = new Autok(id, rendszam, gyarto, modell, kategoria, ar, allapot);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Hiba történt a legdrágább autó lekérdezésekor: " + ex.Message);
            }

            return mostExpensiveCar;
        }

    }
}
