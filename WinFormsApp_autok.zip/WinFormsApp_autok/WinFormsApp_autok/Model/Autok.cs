﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp_autok.Model
{
    public class Autok
    {
        #region PRIVATE FIELDS
        private int id;
        private string rendszam;
        private string gyarto;
        private string modell;
        private string kategoria;
        private decimal ar; // Módosítás: az ár típusa decimal
        private int allapot;
        #endregion

        #region CONSTRUCTOR
        public Autok(int id, string rendszam, string? gyarto, string modell, string kategoria, decimal ar, int allapot)
        {
            this.Id = id;
            this.Rendszam = rendszam;
            this.Gyarto = gyarto;
            this.Modell = modell;
            this.Kategoria = kategoria;
            this.Ar = ar;
            this.Allapot = allapot;
        }
        #endregion

        #region PROPERTIES
        public int Id { get => id; set => id = value; }
        public string Rendszam { get => rendszam; set => rendszam = value; }
        public string Gyarto { get => gyarto; set => gyarto = value; }
        public string Modell { get => modell; set => modell = value; }
        public string Kategoria { get => kategoria; set => kategoria = value; }
        public decimal Ar { get => ar; set => ar = value; } // Módosítás: az ár típusa decimal
        public int Allapot { get => allapot; set => allapot = value; }
        #endregion
    }



}

