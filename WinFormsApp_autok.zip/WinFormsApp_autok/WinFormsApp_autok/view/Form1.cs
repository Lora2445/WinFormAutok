using WinFormsApp_autok._utils;
using WinFormsApp_autok.Model;
using WinFormsApp_autok.view;

namespace WinFormsApp_autok
{
    public partial class Form1 : Form
    {
        private AutokDao autokDao;
        public Form1()
        {
            InitializeComponent();
            LoadList();
            autokDao = new AutokDao();
        }

        public void LoadList()
        {
            Database databaseObj = new Database();
            databaseObj.Connect();

            databaseObj.CloseConnection();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnNewCar_Click(object sender, EventArgs e)
        {
            
            newAuto formNewAuto = new newAuto(); // �j p�ld�ny l�trehoz�sa a newAuto oszt�lyb�l
            formNewAuto.Show(); // Az �rlap megjelen�t�se
            
        
        }

        private void btnAtlag_Click(object sender, EventArgs e)
        {
            decimal averagePrice = autokDao.GetAveragePrice(); // �tlag�r lek�rdez�se AutokDao oszt�lyb�l

            if (averagePrice > 0)
            {
                MessageBox.Show($"Az �tlag�r: {averagePrice} Ft");
            }
            else
            {
                MessageBox.Show("Nincs el�rhet� adat az �tlag�r sz�m�t�s�hoz.");
            }
        }

    
        private void btnLegdragabb_Click(object sender, EventArgs e)
        {
        Autok mostExpensiveCar = autokDao.GetMostExpensiveCar(); // autokDao haszn�lata a met�dusban
        if (mostExpensiveCar != null)
        {
            MessageBox.Show($"A legdr�g�bb aut�: {mostExpensiveCar.Gyarto} {mostExpensiveCar.Modell}, �ra: {mostExpensiveCar.Ar} Ft");
        }
        else
        {
            MessageBox.Show("Nincs adat a legdr�g�bb aut�r�l.");
        }
    }
        }

        
}

