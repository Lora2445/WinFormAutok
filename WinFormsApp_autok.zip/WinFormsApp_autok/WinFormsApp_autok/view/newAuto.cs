﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormsApp_autok.Model;

namespace WinFormsApp_autok.view
{
    public partial class newAuto : Form
    {
        public newAuto()
        {
            InitializeComponent();
            comboBox1.Items.Add("személyautó");
            comboBox1.Items.Add("teherautó");
            comboBox1.Items.Add("egyéb");
            comboBox1.SelectedIndex = 0;
        }
        public newAuto(string rendszam, string gyarto, string modell, string kategoria, decimal nettoAr, bool allapot)
        {
            InitializeComponent();
            // Mezők beállítása a kapott adatokkal
            textBox1.Text = rendszam;
            textBox2.Text = gyarto;
            textBox3.Text = modell;
            textBox4.Text = kategoria;
            textBox5.Text = nettoAr.ToString();
            textBox6.Text = allapot ? "1" : "0"; // Állapot bool érték stringgé alakítása
        }
        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void newAuto_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SaveFormDataToDatabase();
            ResetFormData();
        }

        private void SaveFormDataToDatabase()
        {
            try
            {
                
                string rendszam = textBox1.Text;
                string gyarto = textBox2.Text;
                string modell = textBox3.Text;
                string kategoria = textBox4.Text;
                decimal nettoAr = decimal.Parse(textBox5.Text);
                bool allapot = textBox6.Text == "1" ? true : false;

                
                AutokDao autokDao = new AutokDao();
                autokDao.AddAuto(rendszam, gyarto, modell, kategoria, nettoAr, allapot);

                
                MessageBox.Show("Az adatok sikeresen el lettek mentve az adatbázisba.", "Mentés sikeres", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba történt az adatok mentése közben: " + ex.Message, "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void ResetFormData()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            comboBox1.SelectedIndex = 0;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
