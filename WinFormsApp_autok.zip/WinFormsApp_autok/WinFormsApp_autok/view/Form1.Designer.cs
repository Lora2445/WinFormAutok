﻿namespace WinFormsApp_autok
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            btnNewCar = new Button();
            btnAtlag = new Button();
            btnLegdragabb = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(40, 37);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 82;
            dataGridView1.RowTemplate.Height = 41;
            dataGridView1.Size = new Size(605, 378);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // btnNewCar
            // 
            btnNewCar.Location = new Point(718, 37);
            btnNewCar.Name = "btnNewCar";
            btnNewCar.Size = new Size(302, 46);
            btnNewCar.TabIndex = 1;
            btnNewCar.Text = "Új felvitele";
            btnNewCar.UseVisualStyleBackColor = true;
            btnNewCar.Click += btnNewCar_Click;
            // 
            // btnAtlag
            // 
            btnAtlag.Location = new Point(718, 215);
            btnAtlag.Name = "btnAtlag";
            btnAtlag.Size = new Size(302, 46);
            btnAtlag.TabIndex = 2;
            btnAtlag.Text = "Átlag nettó ár";
            btnAtlag.UseVisualStyleBackColor = true;
            btnAtlag.Click += btnAtlag_Click;
            // 
            // btnLegdragabb
            // 
            btnLegdragabb.Location = new Point(718, 279);
            btnLegdragabb.Name = "btnLegdragabb";
            btnLegdragabb.Size = new Size(302, 46);
            btnLegdragabb.TabIndex = 3;
            btnLegdragabb.Text = "Legdrágább autó";
            btnLegdragabb.UseVisualStyleBackColor = true;
            btnLegdragabb.Click += btnLegdragabb_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1120, 450);
            Controls.Add(btnLegdragabb);
            Controls.Add(btnAtlag);
            Controls.Add(btnNewCar);
            Controls.Add(dataGridView1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dataGridView1;
        private Button btnNewCar;
        private Button btnAtlag;
        private Button btnLegdragabb;
    }
}
